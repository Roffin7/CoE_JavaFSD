export interface Message {
    id: string;
    user: string;
    message: string;
    imageUrl: string;
}