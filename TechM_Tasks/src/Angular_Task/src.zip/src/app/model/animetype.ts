export interface AnimeType {
    id: string;
    title: string;
    imageUrl: string;
    description: string;
    genre: string[];
}